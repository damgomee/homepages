---
title: "IALAB"

description: "강원대학교 정보보증(Information Assurance)연구실 방문을 환영합니다."
# 1. To ensure Netlify triggers a build on our exampleSite instance, we need to change a file in the exampleSite directory.
theme_version: '2.8.2'
cascade:
  featured_image: '/images/kkkk.PNG'
---
Kangwon National University
Information Assurance Lab.



아래는 주요 뉴스입니다.