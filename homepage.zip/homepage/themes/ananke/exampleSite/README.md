## gohugo-theme-ananke-example

This `exampleSite` is based on the submodule-based installation. To learn about a module-based example repository, see the [Ananke Module Example](https://github.com/davidsneighbour/gohugo-theme-ananke-example) repository.
